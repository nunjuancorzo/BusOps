# Script de configuracion automatica de BusOps en IIS
# Ejecutar como Administrador despues de copiar los archivos de publicacion

param(
    [string]$SiteName = "BusOps",
    [string]$AppPoolName = "BusOps",
    [string]$PhysicalPath = "C:\inetpub\wwwroot\BusOps",
    [int]$HttpPort = 80,
    [int]$HttpsPort = 443,
    [string]$HostName = ""
)

Write-Host "================================================" -ForegroundColor Cyan
Write-Host "    CONFIGURACION DE BUSOPS EN IIS             " -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""

# Verificar si se ejecuta como administrador
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "ERROR: Este script debe ejecutarse como Administrador" -ForegroundColor Red
    pause
    exit
}

# Importar modulo de IIS
Import-Module WebAdministration -ErrorAction SilentlyContinue
if (-not (Get-Module -Name WebAdministration)) {
    Write-Host "ERROR: Modulo WebAdministration no disponible" -ForegroundColor Red
    Write-Host "Asegurate de que IIS este instalado correctamente" -ForegroundColor Yellow
    pause
    exit
}

Write-Host "[OK] Modulo IIS cargado" -ForegroundColor Green
Write-Host ""

# Verificar que exista la carpeta de archivos
if (-not (Test-Path $PhysicalPath)) {
    Write-Host "ERROR: La carpeta de archivos no existe: $PhysicalPath" -ForegroundColor Red
    Write-Host "Por favor, copia primero los archivos de publicacion a esta ubicacion" -ForegroundColor Yellow
    pause
    exit
}

Write-Host "[OK] Carpeta de archivos encontrada: $PhysicalPath" -ForegroundColor Green
Write-Host ""

# 1. Crear Application Pool
Write-Host "1. Configurando Application Pool..." -ForegroundColor Yellow

# Eliminar pool si ya existe
if (Test-Path "IIS:\AppPools\$AppPoolName") {
    Write-Host "   Application Pool '$AppPoolName' ya existe, eliminando..." -ForegroundColor Yellow
    Remove-WebAppPool -Name $AppPoolName
    Start-Sleep -Seconds 2
}

# Crear nuevo pool
New-WebAppPool -Name $AppPoolName | Out-Null
Set-ItemProperty "IIS:\AppPools\$AppPoolName" -Name "managedRuntimeVersion" -Value ""
Set-ItemProperty "IIS:\AppPools\$AppPoolName" -Name "enable32BitAppOnWin64" -Value $false
Set-ItemProperty "IIS:\AppPools\$AppPoolName" -Name "processModel.idleTimeout" -Value "00:20:00"
Set-ItemProperty "IIS:\AppPools\$AppPoolName" -Name "recycling.periodicRestart.time" -Value "1.05:00:00"

Write-Host "[OK] Application Pool '$AppPoolName' creado y configurado" -ForegroundColor Green
Write-Host ""

# 2. Crear o actualizar sitio web
Write-Host "2. Configurando sitio web..." -ForegroundColor Yellow

# Eliminar sitio si ya existe
if (Test-Path "IIS:\Sites\$SiteName") {
    Write-Host "   Sitio web '$SiteName' ya existe, eliminando..." -ForegroundColor Yellow
    Remove-Website -Name $SiteName
    Start-Sleep -Seconds 2
}

# Crear sitio web
if ($HostName -eq "") {
    New-Website -Name $SiteName -PhysicalPath $PhysicalPath -ApplicationPool $AppPoolName -Port $HttpPort | Out-Null
}
else {
    New-Website -Name $SiteName -PhysicalPath $PhysicalPath -ApplicationPool $AppPoolName -Port $HttpPort -HostHeader $HostName | Out-Null
}

Write-Host "[OK] Sitio web '$SiteName' creado" -ForegroundColor Green
Write-Host ""

# 3. Configurar permisos
Write-Host "3. Configurando permisos de carpeta..." -ForegroundColor Yellow

$acl = Get-Acl $PhysicalPath
$appPoolIdentity = "IIS AppPool\$AppPoolName"
$rule = New-Object System.Security.AccessControl.FileSystemAccessRule($appPoolIdentity, "ReadAndExecute", "ContainerInherit,ObjectInherit", "None", "Allow")
$acl.SetAccessRule($rule)
Set-Acl $PhysicalPath $acl

# Permisos especiales para carpeta logs
$logsPath = Join-Path $PhysicalPath "logs"
if (Test-Path $logsPath) {
    $aclLogs = Get-Acl $logsPath
    $ruleLogs = New-Object System.Security.AccessControl.FileSystemAccessRule($appPoolIdentity, "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")
    $aclLogs.SetAccessRule($ruleLogs)
    Set-Acl $logsPath $aclLogs
    Write-Host "[OK] Permisos configurados (incluida carpeta logs)" -ForegroundColor Green
}
else {
    Write-Host "ADVERTENCIA: Carpeta logs no encontrada, creandola..." -ForegroundColor Yellow
    New-Item -Path $logsPath -ItemType Directory -Force | Out-Null
    $aclLogs = Get-Acl $logsPath
    $ruleLogs = New-Object System.Security.AccessControl.FileSystemAccessRule($appPoolIdentity, "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")
    $aclLogs.SetAccessRule($ruleLogs)
    Set-Acl $logsPath $aclLogs
    Write-Host "[OK] Carpeta logs creada con permisos" -ForegroundColor Green
}
Write-Host ""

# 4. Verificar archivos criticos
Write-Host "4. Verificando archivos criticos..." -ForegroundColor Yellow

$criticalFiles = @(
    "BusOps.dll",
    "web.config",
    "appsettings.json",
    "appsettings.Production.json"
)

$allFilesExist = $true
foreach ($file in $criticalFiles) {
    $filePath = Join-Path $PhysicalPath $file
    if (Test-Path $filePath) {
        Write-Host "   [OK] $file" -ForegroundColor Green
    }
    else {
        Write-Host "   [X] $file NO ENCONTRADO" -ForegroundColor Red
        $allFilesExist = $false
    }
}

if (-not $allFilesExist) {
    Write-Host ""
    Write-Host "ADVERTENCIA: Faltan archivos criticos" -ForegroundColor Yellow
    Write-Host "La aplicacion puede no funcionar correctamente" -ForegroundColor Yellow
}
Write-Host ""

# 5. Iniciar el sitio
Write-Host "5. Iniciando sitio web..." -ForegroundColor Yellow
Start-Website -Name $SiteName
Start-Sleep -Seconds 2

$siteState = (Get-Website -Name $SiteName).State
if ($siteState -eq "Started") {
    Write-Host "[OK] Sitio web iniciado correctamente" -ForegroundColor Green
}
else {
    Write-Host "ADVERTENCIA: El sitio no se inicio automaticamente. Estado: $siteState" -ForegroundColor Yellow
}
Write-Host ""

# Resumen
Write-Host "================================================" -ForegroundColor Cyan
Write-Host "         CONFIGURACION COMPLETADA              " -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "INFORMACION DEL SITIO:" -ForegroundColor Yellow
Write-Host "  Nombre: $SiteName" -ForegroundColor White
Write-Host "  Application Pool: $AppPoolName" -ForegroundColor White
Write-Host "  Ruta fisica: $PhysicalPath" -ForegroundColor White
Write-Host "  Puerto HTTP: $HttpPort" -ForegroundColor White
if ($HostName -ne "") {
    Write-Host "  Host name: $HostName" -ForegroundColor White
}
Write-Host ""
Write-Host "ACCESO LOCAL:" -ForegroundColor Yellow
if ($HostName -eq "") {
    Write-Host "  http://localhost:$HttpPort" -ForegroundColor Cyan
}
else {
    Write-Host "  http://${HostName}:$HttpPort" -ForegroundColor Cyan
}
Write-Host ""
Write-Host "ACCESO DESDE RED:" -ForegroundColor Yellow
$localIP = (Get-NetIPAddress -AddressFamily IPv4 | Where-Object {$_.InterfaceAlias -notlike "*Loopback*" -and $_.IPAddress -notlike "169.254.*"} | Select-Object -First 1).IPAddress
if ($localIP) {
    Write-Host "  http://${localIP}:$HttpPort" -ForegroundColor Cyan
}
Write-Host ""
Write-Host "PROXIMOS PASOS:" -ForegroundColor Yellow
Write-Host "1. Verificar que MySQL este corriendo" -ForegroundColor White
Write-Host "2. Probar acceso en navegador" -ForegroundColor White
Write-Host "3. Revisar logs si hay errores: $PhysicalPath\logs\" -ForegroundColor White
Write-Host "4. Configurar HTTPS (opcional pero recomendado)" -ForegroundColor White
Write-Host ""
Write-Host "================================================" -ForegroundColor Cyan

# Preguntar si desea abrir el navegador
Write-Host ""
$openBrowser = Read-Host "Desea abrir el sitio en el navegador ahora? (S/N)"
if ($openBrowser -eq "S" -or $openBrowser -eq "s") {
    Start-Process "http://localhost:$HttpPort"
}
