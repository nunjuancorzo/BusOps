# 🚀 BusOps - Archivos de Publicación para IIS

## 📦 CONTENIDO DE ESTA CARPETA

Esta carpeta contiene todos los archivos necesarios para ejecutar BusOps en un servidor Windows con IIS.

---

## ⚡ INSTALACIÓN RÁPIDA (3 PASOS)

### PASO 1: Instalar Requisitos Previos

Ejecutar como Administrador el script:
```powershell
.\instalar_requisitos.ps1
```

Este script instalará:
- ✅ IIS (Internet Information Services)
- ✅ .NET 8.0 Hosting Bundle
- ✅ Configuración de firewall
- ✅ Estructura de carpetas

**IMPORTANTE**: Reiniciar el servidor después de este paso.

---

### PASO 2: Instalar MySQL

1. Descargar MySQL Server 8.0 desde:
   https://dev.mysql.com/downloads/mysql/

2. Durante la instalación configurar:
   - Usuario: `root`
   - Contraseña: `A76262136.r`
   - Permitir conexiones desde localhost
   - Servicio con inicio automático

3. Importar la base de datos (ver sección "Base de Datos" abajo)

---

### PASO 3: Configurar IIS

1. **OPCIÓN A - Automática (Recomendada)**
   
   Copiar todos los archivos de esta carpeta a:
   ```
   C:\inetpub\wwwroot\BusOps\
   ```
   
   Ejecutar como Administrador:
   ```powershell
   cd C:\inetpub\wwwroot\BusOps
   .\configurar_iis.ps1
   ```

2. **OPCIÓN B - Manual**
   
   Ver la guía completa en: `INSTALACION_IIS.md` (en la raíz del proyecto)

---

## 🗄️ BASE DE DATOS

### Importar datos

Los scripts SQL están en la carpeta `Database/` del proyecto original.

**Opción 1 - Ejecutar scripts uno por uno:**
```bash
cd ruta\a\Database
mysql -u root -pA76262136.r busops < 01_create_tables.sql
mysql -u root -pA76262136.r busops < 02_insert_test_data.sql
# ... continuar con el resto de scripts en orden
```

**Opción 2 - Si tienes un backup completo:**
```bash
mysql -u root -pA76262136.r busops < backup_completo.sql
```

### Verificar importación
```bash
mysql -u root -pA76262136.r -e "USE busops; SHOW TABLES;"
```

---

## 🌐 ACCESO A LA APLICACIÓN

Después de la configuración:

### Acceso local (desde el servidor):
```
http://localhost
```

### Acceso desde la red local:
```
http://[IP-DEL-SERVIDOR]
```

Para obtener la IP del servidor:
```powershell
ipconfig
```
Buscar "IPv4 Address"

---

## 📋 ARCHIVOS IMPORTANTES

- **BusOps.dll** - Aplicación principal
- **web.config** - Configuración de IIS
- **appsettings.json** - Configuración general
- **appsettings.Production.json** - Configuración de producción
- **instalar_requisitos.ps1** - Script de instalación de requisitos
- **configurar_iis.ps1** - Script de configuración automática de IIS

---

## 🔧 CONFIGURACIÓN

### Connection String

La aplicación se conectará a MySQL usando la configuración en `appsettings.Production.json`:

```json
"ConnectionStrings": {
  "DefaultConnection": "Server=localhost;Database=busops;User=root;Password=A76262136.r;AllowPublicKeyRetrieval=true;SslMode=none;"
}
```

Si necesitas cambiar la conexión a la base de datos, edita este archivo.

---

## 📊 VERIFICACIÓN

### 1. Verificar que IIS está corriendo
```powershell
Get-Service W3SVC
```
Debe mostrar: Status = Running

### 2. Verificar que MySQL está corriendo
```powershell
Get-Service MySQL*
```
Debe mostrar: Status = Running

### 3. Probar conexión a MySQL
```bash
mysql -u root -pA76262136.r -e "SELECT VERSION();"
```

### 4. Ver logs de la aplicación
Si hay problemas, revisar:
```
C:\inetpub\wwwroot\BusOps\logs\stdout_YYYYMMDD.log
```

---

## 🛠️ SOLUCIÓN DE PROBLEMAS

### Error 500.19 - Error de configuración
**Solución**: Instalar .NET 8.0 Hosting Bundle y reiniciar

### Error 502.5 - Error al iniciar el proceso
**Solución**: 
1. Verificar instalación de .NET: `dotnet --info`
2. Revisar logs en carpeta `logs/`

### No conecta a la base de datos
**Solución**:
1. Verificar MySQL: `Get-Service MySQL*`
2. Probar conexión: `mysql -u root -pA76262136.r`
3. Verificar connection string en `appsettings.Production.json`

### El sitio no es accesible desde otros equipos
**Solución**:
1. Verificar firewall de Windows
2. Ejecutar como Admin:
   ```powershell
   New-NetFirewallRule -DisplayName "BusOps HTTP" -Direction Inbound -LocalPort 80 -Protocol TCP -Action Allow
   ```

---

## 📞 INFORMACIÓN TÉCNICA

- **Framework**: .NET 8.0
- **Tipo**: Blazor Server (InteractiveServer)
- **Base de datos**: MySQL 8.0+
- **Hosting Model**: In-Process
- **Plataforma**: Windows Server 2016+ / Windows 10+

---

## 📚 DOCUMENTACIÓN COMPLETA

Para instrucciones detalladas paso a paso, consulta:

**INSTALACION_IIS.md** - Ubicado en la raíz del proyecto

Este documento incluye:
- Requisitos previos detallados
- Configuración manual de IIS
- Solución de problemas comunes
- Configuración de HTTPS
- Acceso desde Internet
- Actualizaciones futuras

---

## ✅ CHECKLIST PRE-PRODUCCIÓN

Antes de usar en producción, verificar:

- [ ] .NET 8.0 Hosting Bundle instalado
- [ ] Servidor reiniciado después de instalar .NET
- [ ] MySQL instalado y corriendo
- [ ] Base de datos importada completamente
- [ ] Usuario de prueba funcional
- [ ] IIS configurado y sitio iniciado
- [ ] Application Pool corriendo
- [ ] Permisos de carpeta configurados
- [ ] Firewall con puertos abiertos
- [ ] Acceso local funciona
- [ ] Acceso desde red funciona
- [ ] Logs sin errores críticos

---

## 🔄 ACTUALIZACIONES

Para actualizar en el futuro:

1. Detener sitio en IIS
2. Hacer backup de la carpeta actual
3. Reemplazar archivos (excepto appsettings si tiene cambios)
4. Iniciar sitio en IIS

---

**Versión**: Beta 20260219  
**Contacto**: infobusops@gmail.com

🚌 **¡BusOps - Gestión Integral de Empresas de Autobuses!** ✨
