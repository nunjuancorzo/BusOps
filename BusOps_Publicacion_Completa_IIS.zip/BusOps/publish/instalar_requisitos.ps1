# Script de instalacion de requisitos previos para BusOps en Windows Server
# Ejecutar como Administrador

Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  INSTALACION DE REQUISITOS PREVIOS - BUSOPS  " -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""

# Verificar si se ejecuta como administrador
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "ERROR: Este script debe ejecutarse como Administrador" -ForegroundColor Red
    Write-Host "Clic derecho en PowerShell -> Ejecutar como administrador" -ForegroundColor Yellow
    pause
    exit
}

Write-Host "[OK] Ejecutando como Administrador" -ForegroundColor Green
Write-Host ""

# 1. Instalacion de IIS
Write-Host "1. Instalando IIS y componentes necesarios..." -ForegroundColor Yellow
$features = @(
    "IIS-WebServerRole",
    "IIS-WebServer",
    "IIS-CommonHttpFeatures",
    "IIS-HttpErrors",
    "IIS-HttpRedirect",
    "IIS-ApplicationDevelopment",
    "IIS-NetFxExtensibility45",
    "IIS-HealthAndDiagnostics",
    "IIS-HttpLogging",
    "IIS-LoggingLibraries",
    "IIS-RequestMonitor",
    "IIS-HttpTracing",
    "IIS-Security",
    "IIS-RequestFiltering",
    "IIS-Performance",
    "IIS-WebServerManagementTools",
    "IIS-IIS6ManagementCompatibility",
    "IIS-Metabase",
    "IIS-ManagementConsole",
    "IIS-BasicAuthentication",
    "IIS-WindowsAuthentication",
    "IIS-StaticContent",
    "IIS-DefaultDocument",
    "IIS-DirectoryBrowsing",
    "IIS-ASPNET45",
    "IIS-ISAPIExtensions",
    "IIS-ISAPIFilter",
    "IIS-HttpCompressionStatic"
)

foreach ($feature in $features) {
    Enable-WindowsOptionalFeature -Online -FeatureName $feature -All -NoRestart -ErrorAction SilentlyContinue | Out-Null
}

Write-Host "[OK] IIS instalado" -ForegroundColor Green
Write-Host ""

# 2. Descargar e instalar .NET 8.0 Hosting Bundle
Write-Host "2. Descargando .NET 8.0 Hosting Bundle..." -ForegroundColor Yellow
$dotnetUrl = "https://download.visualstudio.microsoft.com/download/pr/751d3fcd-72db-4da2-b8d0-709c19442225/6a62d7f6b063fb439671c48b1f17c50e/dotnet-hosting-8.0.2-win.exe"
$dotnetInstaller = "$env:TEMP\dotnet-hosting-8.0.2-win.exe"

try {
    Invoke-WebRequest -Uri $dotnetUrl -OutFile $dotnetInstaller -UseBasicParsing
    Write-Host "[OK] Descarga completada" -ForegroundColor Green
    
    Write-Host "Instalando .NET 8.0 Hosting Bundle (esto puede tardar unos minutos)..." -ForegroundColor Yellow
    Start-Process -FilePath $dotnetInstaller -ArgumentList "/install /quiet /norestart" -Wait
    Write-Host "[OK] .NET 8.0 Hosting Bundle instalado" -ForegroundColor Green
    
    # Limpiar archivo temporal
    Remove-Item $dotnetInstaller -Force -ErrorAction SilentlyContinue
}
catch {
    Write-Host "ADVERTENCIA: No se pudo descargar automaticamente .NET 8.0" -ForegroundColor Yellow
    Write-Host "Por favor, descargalo manualmente de:" -ForegroundColor Yellow
    Write-Host "https://dotnet.microsoft.com/download/dotnet/8.0" -ForegroundColor Cyan
}
Write-Host ""

# 3. Verificar instalacion de .NET
Write-Host "3. Verificando instalacion de .NET..." -ForegroundColor Yellow
try {
    $dotnetVersion = & dotnet --version
    Write-Host "[OK] .NET version: $dotnetVersion" -ForegroundColor Green
}
catch {
    Write-Host "ADVERTENCIA: .NET no detectado. Puede requerir reinicio del sistema." -ForegroundColor Yellow
}
Write-Host ""

# 4. Configurar firewall
Write-Host "4. Configurando reglas de firewall..." -ForegroundColor Yellow
New-NetFirewallRule -DisplayName "BusOps HTTP (Port 80)" -Direction Inbound -LocalPort 80 -Protocol TCP -Action Allow -ErrorAction SilentlyContinue | Out-Null
New-NetFirewallRule -DisplayName "BusOps HTTPS (Port 443)" -Direction Inbound -LocalPort 443 -Protocol TCP -Action Allow -ErrorAction SilentlyContinue | Out-Null
Write-Host "[OK] Puertos 80 y 443 abiertos en firewall" -ForegroundColor Green
Write-Host ""

# 5. Crear estructura de carpetas
Write-Host "5. Creando estructura de carpetas..." -ForegroundColor Yellow
$busopsPath = "C:\inetpub\wwwroot\BusOps"
if (-not (Test-Path $busopsPath)) {
    New-Item -Path $busopsPath -ItemType Directory -Force | Out-Null
    Write-Host "[OK] Carpeta creada: $busopsPath" -ForegroundColor Green
}
else {
    Write-Host "[OK] Carpeta ya existe: $busopsPath" -ForegroundColor Green
}

$logsPath = "$busopsPath\logs"
if (-not (Test-Path $logsPath)) {
    New-Item -Path $logsPath -ItemType Directory -Force | Out-Null
    Write-Host "[OK] Carpeta de logs creada: $logsPath" -ForegroundColor Green
}
else {
    Write-Host "[OK] Carpeta de logs ya existe: $logsPath" -ForegroundColor Green
}
Write-Host ""

# Resumen
Write-Host "================================================" -ForegroundColor Cyan
Write-Host "           INSTALACION COMPLETADA              " -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "PROXIMOS PASOS:" -ForegroundColor Yellow
Write-Host ""
Write-Host "1. REINICIAR EL SERVIDOR (importante para que .NET funcione correctamente)" -ForegroundColor White
Write-Host ""
Write-Host "2. Instalar MySQL Server:" -ForegroundColor White
Write-Host "   - Descargar de: https://dev.mysql.com/downloads/mysql/" -ForegroundColor Cyan
Write-Host "   - Usuario: root" -ForegroundColor Cyan
Write-Host "   - Contrasena: A76262136.r" -ForegroundColor Cyan
Write-Host ""
Write-Host "3. Copiar archivos de BusOps a:" -ForegroundColor White
Write-Host "   $busopsPath" -ForegroundColor Cyan
Write-Host ""
Write-Host "4. Configurar IIS siguiendo la guia INSTALACION_IIS.md" -ForegroundColor White
Write-Host ""
Write-Host "================================================" -ForegroundColor Cyan

# Preguntar si desea reiniciar ahora
Write-Host ""
$restart = Read-Host "Desea reiniciar el servidor ahora? (S/N)"
if ($restart -eq "S" -or $restart -eq "s") {
    Write-Host "Reiniciando en 10 segundos..." -ForegroundColor Yellow
    Write-Host "Presione Ctrl+C para cancelar" -ForegroundColor Yellow
    Start-Sleep -Seconds 10
    Restart-Computer -Force
}
else {
    Write-Host "Recuerda reiniciar el servidor antes de continuar con la instalacion." -ForegroundColor Yellow
}
